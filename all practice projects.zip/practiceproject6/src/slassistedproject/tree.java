package slassistedproject;

import java.util.Map;
import java.util.TreeMap;

public class tree {

	public static void main(String[] args) {
	      //TreeMap
	      
	      TreeMap<Integer,String> map=new TreeMap<Integer,String>();    
	      map.put(8,"dora");    
	      map.put(9,"vamsi");    
	      map.put(10,"john");       
	      
	      System.out.println("\nThe elements of TreeMap are ");  
	      for(Map.Entry l:map.entrySet()){    
	       System.out.println(l.getKey()+" "+l.getValue());    
	      }    
	      
	   }  



	}


