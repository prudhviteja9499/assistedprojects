package slassistedproject;


		import java.util.*;
		public class map {

			public static void main(String[] args) {
				// map
				
				
				HashMap<Integer,String> hm=new HashMap<Integer,String>();      
			      hm.put(1,"prudhvi");    
			      hm.put(2,"sobith");    
			      hm.put(3,"rohit");   
			       
			      System.out.println("\nThe elements of Hashmap are ");  
			      for(Map.Entry m:hm.entrySet()){    
			       System.out.println(m.getKey()+" "+m.getValue());    
			      }


	}

}
