package publica;

	import slassistedproject2.*;

	public class publicacess {

		public static void main(String[] args) {
			
			publicacessspecifiers obj = new publicacessspecifiers(); 
	        obj.display();  
			
		}
	}



