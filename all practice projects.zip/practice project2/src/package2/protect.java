package package2;

import slassistedproject2.*;

public class protect extends protectedaccessspecifiers {

	public static void main(String[] args) {
		protect obj = new protect ();   
	       obj.display();  
	}

}
